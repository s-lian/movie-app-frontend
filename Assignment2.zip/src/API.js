const API_URL = `http://sefdb02.qut.edu.au:3000/`

export default API_URL;