export default function Footer() {

    return (

        <footer>

            <span>
                All data is from IMBD, Metacritic and RottenTomatoes.
                <br /> Copyright &copy; FirstName LastName
            </span>
        </footer>
    )
}